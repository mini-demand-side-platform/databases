--
-- PostgreSQL database dump
--

-- Dumped from database version 12.5
-- Dumped by pg_dump version 12.5

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: feature; Type: TABLE; Schema: public; Owner: dsp
--

CREATE TABLE public.feature (
    feature_store_id character(8),
    feature_id character(8) DEFAULT "substring"(((public.uuid_generate_v4())::character(8))::text, 1, 8) NOT NULL,
    feature_name character varying(50),
    source_table_name character varying(50),
    source_column_name character varying(50),
    feature_function_type character varying(50),
    description character varying(50),
    function_name character varying(50)
);


ALTER TABLE public.feature OWNER TO dsp;

--
-- Name: feature_store; Type: TABLE; Schema: public; Owner: dsp
--

CREATE TABLE public.feature_store (
    feature_store_id character(8) DEFAULT "substring"(((public.uuid_generate_v4())::character(8))::text, 1, 8) NOT NULL,
    feature_store_name character varying(50),
    description character varying(50),
    offline_table_name character varying(50)
);


ALTER TABLE public.feature_store OWNER TO dsp;

--
-- Name: feature feature_pkey; Type: CONSTRAINT; Schema: public; Owner: dsp
--

ALTER TABLE ONLY public.feature
    ADD CONSTRAINT feature_pkey PRIMARY KEY (feature_id);


--
-- Name: feature_store feature_store_pkey; Type: CONSTRAINT; Schema: public; Owner: dsp
--

ALTER TABLE ONLY public.feature_store
    ADD CONSTRAINT feature_store_pkey PRIMARY KEY (feature_store_id);


--
-- Name: feature feature_feature_store_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dsp
--

ALTER TABLE ONLY public.feature
    ADD CONSTRAINT feature_feature_store_id_fkey FOREIGN KEY (feature_store_id) REFERENCES public.feature_store(feature_store_id);


--
-- PostgreSQL database dump complete
--

