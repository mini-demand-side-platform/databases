--
-- PostgreSQL database dump
--

-- Dumped from database version 12.5
-- Dumped by pg_dump version 12.5

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Data for Name: feature_store; Type: TABLE DATA; Schema: public; Owner: dsp
--

COPY public.feature_store (feature_store_id, feature_store_name, description, offline_table_name) FROM stdin;
cdc74d4c	mini-demand-side-platform	choice top 10 feature from correlation	top_10_features
\.


--
-- Data for Name: feature; Type: TABLE DATA; Schema: public; Owner: dsp
--

COPY public.feature (feature_store_id, feature_id, feature_name, source_table_name, source_column_name, feature_function_type, description, function_name) FROM stdin;
cdc74d4c	5dbfb549	layout_style_AB	ctr	layout_style	string_mapping	map layout_style AB to 1	layout_style_AB
cdc74d4c	ea2f676f	layout_style_RU	ctr	layout_style	string_mapping	map layout_style RU to 1	layout_style_RU
cdc74d4c	0ad63312	layout_style_GY	ctr	layout_style	string_mapping	map layout_style GY to 1	layout_style_GY
cdc74d4c	a2480212	layout_style_MR	ctr	layout_style	string_mapping	map layout_style MR to 1	layout_style_MR
cdc74d4c	5aae0b22	layout_style_BK	ctr	layout_style	string_mapping	map layout_style BK to 1	layout_style_BK
cdc74d4c	65934929	layout_style_BX	ctr	layout_style	string_mapping	map layout_style BX to 1	layout_style_BX
cdc74d4c	2658049e	layout_style_RZ	ctr	layout_style	string_mapping	map layout_style RZ to 1	layout_style_RZ
cdc74d4c	717456fc	layout_style_TY	ctr	layout_style	string_mapping	map layout_style TY to 1	layout_style_TY
cdc74d4c	1d34889f	category_Shirt	ctr	category	string_mapping	map category Shirt to 1	category_Shirt
cdc74d4c	915a0c3c	layout_style_DX	ctr	layout_style	string_mapping	map layout_style DX to 1	layout_style_DX
\.


--
-- PostgreSQL database dump complete
--

